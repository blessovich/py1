import tkinter as tk

root = tk.Tk()
root.title("Форма ввода данных")
root.geometry("420x250")
root.resizable(False, False)

tk.Label(root, text="Имя:").grid(row=0, column=0, padx=12, pady=12, sticky="e")
name_entry = tk.Entry(root, width=28)
name_entry.grid(row=0, column=1, padx=12, pady=12)

tk.Label(root, text="Возраст:").grid(row=1, column=0, padx=12, pady=12, sticky="e")
age_entry = tk.Entry(root, width=28)
age_entry.grid(row=1, column=1, padx=12, pady=12)

result_label = tk.Label(root, text="", font=("Arial", 11), wraplength=360)
result_label.grid(row=3, column=0, columnspan=2, padx=12, pady=15)

def show_data():
    name = name_entry.get().strip()
    age = age_entry.get().strip()

    if not name or not age:
        result_label.config(text="Пожалуйста, заполните все поля.", fg="red")
        return

    result_label.config(text=f"{name}, вам {age} лет", fg="green")

show_button = tk.Button(root, text="Показать данные", command=show_data)
show_button.grid(row=2, column=0, columnspan=2, pady=8)

name_entry.focus_set()
root.mainloop()
