import tkinter as tk

root = tk.Tk()
root.title("Информация")
root.geometry("500x300")
root.configure(bg="#f2f6fc")

title = tk.Label(
    root,
    text="Информационная карточка",
    font=("Arial", 18, "bold"),
    bg="#f2f6fc",
    fg="#183153"
)
title.pack(pady=(30, 20))

fio = tk.Label(
    root, text="ФИО: Ваше ФИО",
    font=("Arial", 13), bg="#f2f6fc", fg="#24527a"
)
fio.pack(pady=8)

group = tk.Label(
    root, text="Группа: Ваша группа",
    font=("Arial", 13), bg="#f2f6fc", fg="#24527a"
)
group.pack(pady=8)

subject = tk.Label(
    root, text="Дисциплина: Основы программирования",
    font=("Arial", 13), bg="#f2f6fc", fg="#24527a"
)
subject.pack(pady=8)

root.mainloop()
