import tkinter as tk

root = tk.Tk()
root.title("Кнопка и обработчик")
root.geometry("400x220")

message = tk.Label(root, text="Нажмите кнопку", font=("Arial", 14))
message.pack(pady=30)

def change_text():
    message.config(text="Задание выполнено!")

button = tk.Button(root, text="Выполнить", command=change_text)
button.pack(pady=10)

root.mainloop()
